<?php
ini_set('display_errors', '1');

class SuperMetrics
{

    public function __construct() {

        try {

            if(!isset($_COOKIE["sl_token"]) || $_COOKIE["sl_token"]!="")
            {
                $params="client_id=ju16a6m81mhid5ue1z3v2g0uh&email=hassanphp7@gmail.com&name=Hassan";
                $server_output = $this->curlInit("POST","https://api.supermetrics.com/assignment/register",$params);
                $jsonResoinse = json_decode($server_output);

                setcookie("sl_token", $jsonResoinse->data->sl_token, time()+3600);
            }


        } catch (RequestException $e) {
            echo $e->getMessage();
        }
                 // Outputs the JSON decoded data
    }

    public function getPosts($token="")
    {

        $data=array();
        for($i=1;$i<=10;$i++)
        {
            $params1="?sl_token=".$token."&page=".$i;
            $tokenresponse = $this->curlInit("1","https://api.supermetrics.com/assignment/posts".$params1,$params1);
            $tokenresponse = json_decode($tokenresponse);
            $dataTmp = (array) $tokenresponse->data->posts;

            $data = array_merge($data,$dataTmp);
        }
        return $data;
    }
    function curlInit($method="", $url, $data){
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL,$url);
        if($method=="1")
        {
            curl_setopt($ch, CURLOPT_POST, 0);

        }
        else
        {
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS,
                $data);

        }

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $server_output = curl_exec($ch);

        curl_close ($ch);
        return $server_output;
    }
    function monthlyPosts($data,$month=1)
    {
        $postOfMonth = [];

        foreach($data as $post){
            //$postMonth = Carbon::parse($post->created_time)->month;
            $day  = new DateTime($post->created_time);
            $postMonth = $day->format('m');

            if($postMonth == $month){
                $postOfMonth[] = $post;
            }
        }

        return $postOfMonth;
    }
    function weeklyPosts($data=array())
    {
        $postsByWeek = [];

        foreach($data as $post){
            $day  = new DateTime($post->created_time);
            $dayOfWeek = $day->format('l');


            $postsByWeek[] = ['week' => $dayOfWeek, 'message' => $post->message];
        }

        return $postsByWeek;
    }

}
