<?php
Class Config
{

    public static function d($params=array(),$die=false)
    {
        echo "<pre>";
        print_r($params);
        echo "</pre>";
        if($die)
        {
            die;
        }

    }

    public static function callAPI($method="", $url, $data){
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL,$url);
        if($method=="1")
        {
            curl_setopt($ch, CURLOPT_POST, 0);

        }
        else
        {
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS,
                $data);

        }


// In real life you should use something like:
// curl_setopt($ch, CURLOPT_POSTFIELDS,
//          http_build_query(array('postvar1' => 'value1')));

// Receive server response ...
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $server_output = curl_exec($ch);

        curl_close ($ch);
        return $server_output;
    }

    public static function longestPostByChar($posts=array())
    {
        $temp = array();
        foreach ($posts as $post){
            $temp[] = strlen($post->message);
        }
        if(!empty($temp))
        {
            return max($temp);
        }
        else
        {
            return 0;
        }

    }



    public static function avgPostLengthPerMonth(array $posts)
    {
        $temp = array();
        foreach ($posts as $post){
            $temp[] = strlen($post->message);
        }
        if(!empty($posts))
        {
            $avg = array_sum($temp)/count($temp);
        }
        else
        {
            $avg=0;
        }


        return $avg;
    }

    public static function groupByWeekCount($posts)
    {
        $grouped = self::groupBy($posts, 'week');

        $groupCount = array_map(function ($item) {
            return count($item);
        }, $grouped);

        return self::byYear($groupCount);
    }
    public  static function groupBy($array, $key) {
        $resultArr = array();
        foreach($array as $val) {
            $resultArr[$val[$key]][] = $val;
        }
        return $resultArr;
    }
    public static function byYear(array $groupCount)
    {
        $result = array();

        array_walk($groupCount, function (&$value,$key) use (&$result){
            $result[] = ['weekName'=>$key, 'totalPosts'=>$value];
        });
        return $result;
    }
    public static function avgPostsPerUserPerMonth($posts)
    {
        $grouped = self::groupBy($posts, 'from_id');

        $groupCount = array_map(function ($item) {
            return count($item);
        }, $grouped);
        if(!empty($groupCount))
        {
            return array_sum($groupCount)/count($groupCount);
        }
        else
        {
            return 0;
        }

    }
    public static function absoulute($data)
    {
        return round($data,3);
    }
}