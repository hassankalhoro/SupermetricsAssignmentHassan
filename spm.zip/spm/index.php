<?php
//ini_set('display_errors', '1');
require __DIR__ . '/app/Config.php';

require __DIR__ . '/vendor/autoload.php';
require __DIR__ . '/app/SuperMetrics.php';

$month = isset($_GET['m'])?$_GET['m']:12;

$metrics = new SuperMetrics();
$Config = new Config();
$token = isset($_COOKIE["sl_token"])?$_COOKIE["sl_token"]:"";

if($token!="")
{
    $posts = $metrics->getPosts($token,1);
    $weeklyPosts = (array) $metrics->weeklyPosts($posts);

    $monthlyPosts =  $metrics->monthlyPosts($posts,$month);
    $monthlyPostsArray =  array();
    foreach($monthlyPosts as  $key=>$val)
    {
        $tempArray["id"] = $val->id;
        $tempArray["from_name"] = $val->from_name;
        $tempArray["from_id"] = $val->from_id;
        $tempArray["message"] = $val->message;
        $tempArray["type"] = $val->type;
        $tempArray["created_time"] = $val->created_time;
        $monthlyPostsArray[] = $tempArray;
    }
    $data = [
        'Average character length of posts per month' => $Config::absoulute($Config::avgPostLengthPerMonth($monthlyPosts)),
        'Longest post by character length per month' => $Config::absoulute($Config::longestPostByChar($monthlyPosts)),
        'Total posts split by week number' => $Config::groupByWeekCount($weeklyPosts),
        'Average number of posts per user per month' => $Config::absoulute($Config::avgPostsPerUserPerMonth($monthlyPostsArray)),

    ];
    $Config::d(json_encode($data),1);
}
else
{
    $Config::d(json_encode(["message"=>"Token is not available"]),1);
}